package gb_2;

public class Main {

    public static void main(String[] args) {
        first();
        second();
        third();
        fourth();

    }

    static void first() {
        int[] arr = {1, 1, 0, 0, 1, 0, 1, 1, 0, 1};
        int arr2 = arr.length;
        for (int i = 0; i < arr2; i++) {
            if (arr[i] == 1) arr[i] = 0;
            else arr[i] = 1;
        }
        for (int i = 0; i < arr2; i++) {
            System.out.println(i + "-" + arr[i]);
        }
    }

    static void second() {
        int[] array = new int[8];
        for (int i = 0; i < array.length; i++) {
            array[0] = 0;
            array[1] = 3;
            array[2] = 6;
            array[3] = 9;
            array[4] = 12;
            array[5] = 15;
            array[6] = 18;
            array[7] = 21;


            System.out.println(array[i]);
        }
    }

    static void third() {
        int[] array = {1, 5, 3, 2, 11, 4, 5, 2, 4, 8, 9, 1};
        for (int i = 0; i < array.length; i++) {
            if (array[i] < 6) {
                return array[i] * 2;
            }
            System.out.println(array[i]);
        }
    }


    static void fourth() {
        int[][] arr = new int[2][2];
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                if (i < j) {
                    arr[i][j] = 0;
                } else if (i > j) {
                    arr[i][j] = 1;
                } else {
                    arr[i][j] = 1;
                }
                System.out.print(arr[i][j] + " ");
            }
            System.out.println();
        }
    }
}

